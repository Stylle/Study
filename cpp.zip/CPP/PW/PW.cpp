#include <stdio.h>
#include <string.h>

void pw(char str[100])
{
	for(int i = 0;i < strlen(str);i++)
	{
		if(str[i]=='z')
		{
			printf("a");
			continue;
		}
		printf("%c",str[i]+1);
	}
	printf("\n");
}
void unpw(char str[100])
{
	for(int i = 0;i < strlen(str);i++)
	{
		printf("%c",str[i]);
	}
	printf("\n");
}

int main()
{
	char str[100];

	int flag;

	printf("Plese input str:");
	scanf("%s",str);

	printf("input 1 or 0:");

	scanf("%d",&flag);

	if(flag == 1)
	{
		pw(str);
	}
	else if(flag == 0)
	{
		unpw(str);
	}
	else 	printf("error!\n");

	getchar();
	return 0;
}
