#include <iostream>
#include <string>

using namespace std;

class Person
{
	friend void Person_Puts(Person &p);
	friend ostream& operator<<(ostream &cout,Person p);
//公共权限
public:
	Person(int age,int id,int Height,string name)
	{
		this->m_Age = age;
		this->m_Height = Height;
		this->m_Id = id;
		this->m_Name = name;
	}
	
//保护权限
protected:
	int m_Age;
	int m_Height;
	int m_Id;
	string m_Name;
//私有权限
private:
};

//通过友元函数输出类成员
void Person_Puts(Person &p)
{
	cout<< "姓名 = " <<p.m_Name <<"  年龄 = "<< p.m_Age << endl;
}

//重构<<运算符
ostream& operator<<(ostream &cout,Person p)
{
	cout<<"姓名 = "<<p.m_Name<<" 年龄 = "<<p.m_Age<<" 身高 = "<<p.m_Height \
		<<" ID = "<<p.m_Id;
	return cout;
}

int main()
{
	//创建Person类成员
	Person p(18,100,170,"stylle");
	Person_Puts(p);

	cout<<p<<endl;

	return 0;
}
