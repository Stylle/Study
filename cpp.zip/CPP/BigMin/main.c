#include <stdio.h>

int Big(int num1,int num2)
{
	int result;
	for(result = num1; result >= 0; result--)
	{
		if(num1 % result == 0 && num2 % result == 0)
		{
			return result;
		}
	}
	return 0;
}

int Min(int num1,int num2)
{
	int result;

	result =  num1 * num2 / Big(num1,num2);

	return result;

}

int main()
{
	int num1,num2;
	
	scanf("%d%d",&num1,&num2);

	printf("最小公倍数字：%d\n",Big(num1,num2));

	printf("最大公约数字：%d\n",Min(num1,num2));

	return 0;
}
