#include <iostream>
#include <string>
using namespace std;

/***
 *file:calculator
 *author:stylle
 *time:2020/5/22
 *ps:class  or  virtual
 ***/

class Calculator
{
	public:
		virtual int getResult()
		{
			return 0; 
		}
		int m_A;
		int m_B;
};
class Add_Oper:public Calculator
{
	public:
		int getResult()
		{
			return m_A + m_B;
		}
};
class Sub_Oper:public Calculator
{
	public:
		int getResult()
		{
			return m_A - m_B;
		}
};


//多度的好处：方便拓展、可读性强、结构清晰、可维护能力好
void test01()
{
	Calculator *abs = new Sub_Oper;

	abs->m_A = 45;

	abs->m_B = 23;

	cout << abs->m_A << "-" <<abs->m_B << " = "<< abs->getResult() <<endl;

	abs = new Add_Oper;
	
	abs->m_A = 22;

	abs->m_B = 13;

	cout << abs->m_A << "+" << abs->m_B << " = "<< abs->getResult() <<endl;
};

int main()
{
	test01();

	return 0;
}
