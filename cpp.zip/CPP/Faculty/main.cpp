/*************************************************************************
    > File Name: main.c
    > Author: stylle
    > Mail: 676482793@qq.com 
    > Created Time: 2020年05月24日 星期日 17时38分28秒
 ************************************************************************/
#include <iostream>
#include <string>
#include "myheader.h"

using namespace std;

int main()
{
	HelloWorld();
	return 0; 
}
