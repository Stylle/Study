/*************************************************************************
    > File Name: myheader.h
    > Author: stylle
    > Mail: 676482793@qq.com 
    > Created Time: 2020年05月24日 星期日 17时38分28秒
 ************************************************************************/

#ifndef _MYHEADER_H
#define _MYHEADER_H

#include <iostream>

using namespace std;

void HelloWorld(void);

#endif
