/*************************************************************************
    > File Name: myheader.c
    > Author: stylle
    > Mail: 676482793@qq.com 
    > Created Time: 2020年05月24日 星期日 17时37分29秒
 ************************************************************************/
#include "myheader.h"

void HelloWorld()
{
	cout << "Hello World!" << endl;
}
