#include <iostream>
#include <string>
#include <fstream>

using namespace std;

/****
 * 在多态中父类虚函数无意义，主要调用子类重写函数时
 *
 * 可以把虚函数改为纯虚函数
 *
 * 基本语法： virtual void(返回类型) fun(函数名) (参数列表) = 0;
 *
 * 当这个对象类中有了纯虚函数过后，这个类也叫抽象类
 *
 * 特点：无法实例化对象、子类中必须重修纯虚函数，否则子类也叫抽象类
 *	
 *		实例化对象：无法在堆区和栈区创建该对象属性
 *
 *		抽象类  Base 
 *
 *		Base b;  和  new Base 都是错误的
 *
 * 有重写虚函数过后的抽象类
 *	
 *		Base *b = new 子类
 *
 *		b->虚函数名()；
 * 
 * c++文件操作：包含头文件<fstream>  ->创建流对象 -> 打开文件 -> 写数据  -> 关闭文件
 *	
 *		创建：ofstream ofs;
 *
 *		打开：ofs.open("文件路径"，打开方式);
 *
 *		写数据：ofs<<“写入的数据内容”;
 *
 *		关闭文件: ofs.close();
 *
 * 打开文件方式：
 *		ios::in		 read
 *
 *		ios::out	 wirte
 *		
 *		ios::ate	 初始位置为文件尾
 *		
 *		ios::app	 追加方式写文件 appen
 *		
 *		ios::trunc   如果文件存在删除再创建
 *		
 *		ios::binary  二进制方式
 *	
 *	open方式可以用 “ | ”操作符  例如写二进制文件 ios::binary | ios::out
 *
 * **/


class Schedule
{
	public:
		virtual void Start() = 0;
		virtual void First_Step() = 0;
		virtual void Second_Step() = 0;
		virtual void Stop() = 0;
	
		void Schedule_Display()
		{
			Start();
			First_Step();
			Second_Step();
			Stop();
		}
	protected:

	private:

};
class Reading : public Schedule
{
	public:
		void Start()
		{
			cout<<"今天准备看书"<<endl;
		}
		void First_Step()
		{
			cout<<"找到想看的书籍"<<endl;
		}
		void Second_Step()
		{
			cout<<"开始看书"<<endl;
		}
		void Stop()
		{
			cout<<"今天看书的计划完成"<<endl;
		}
};

class Learn : public Schedule
{
	public:
		void Start()
		{
			cout<<"今天准备学习"<<endl;
		}
		void First_Step()
		{
			cout<<"认真听讲"<<endl;
		}
		void Second_Step()
		{
			cout<<"做好笔记"<<endl;
		}
		void Stop()
		{
			cout<<"完美的一天从学习完成结束"<<endl;
		}
};


void doStep(Schedule *abs)
{
	cout<<"--------------------"<<endl;
	abs->Schedule_Display();
	cout<<"--------------------"<<endl<<endl;
	
	if(abs != NULL)
	{
		delete abs;
		abs = NULL;
	}
}

void test01()
{
	doStep(new Reading);
	doStep(new Learn);
}

//写文件示例
void test02()
{
	//1.创建流对象
	ofstream ofs;

	//2.打开文件  ： 写权限 可用 二进制方式
	ofs.open("test01.txt",ios::out| ios::binary);

	//3.写文件 正常方式
	ofs <<"姓名 = 张三"<<endl;
	ofs <<"年龄 = 19"<<endl;
	ofs <<"身高 = 170cm"<<endl;
	
	//4.写文件 二进制方式
	
	char str[3][10] = {{"李四"},{" = 18\n"}};

	ofs.write((const char *)str,sizeof(str));
	
	//5.关闭文件
	ofs.close();
}

//读文件示例
void test03()
{
	//创建流对象
	ifstream ifs;

	//构造方法初始化：ifstream if("text01.txt",ios:in);

	//打开文件
	ifs.open("test01.txt",ios::in);

	//文件是否打开成功
	if(!ifs.is_open())
	{
		cout<<"文件打开失败"<<endl;
		return;
	}
	//读文件方式	1  数据一个个位移到buf中
	
	char buf[1024] = {};

	//while(ifs>>buf);

	//cout << buf << endl;

	//读文件方式	2 数据一行一行的读取到buf中：ifs的读取方式

	//while(ifs.getline(buf,sizeof(buf)))
	//{
	//	cout << buf <<endl;
	//}
	
	//读文件方式	3 采用getline(数据流，存储变量（string类型）)函数
	//string buf1;

	//while(getline(ifs,buf1))
	//{
	//	cout << buf1 <<endl;
	//}

	//读文件方式	4 单个字符读取方式 不常用速度慢 根据需求来
	
	char ch;

	while((ch = ifs.get()) != EOF)  //EOF   end or file  也就是文件的结尾
	{
		cout<< ch;
	}
	
	//读取二进制文件
	
	ifs.read(buf,sizeof(buf));

	cout << buf << endl;

	//关闭文件
	ifs.close();
}

int main()
{
	test01();

	test02();

	test03();

	return 0;
}
