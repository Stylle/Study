#include <iostream>
using namespace std;
#include <string>

//模板的基本语法

//模板函数的声明  方法1：
//template <typename T>

//模板函数的声明  方法2：
template <class T>

//交换函数
void mySwap(T &a,T &b)
{
	//a = a + b;
	//b = a - b;
	//a = a - b;
	T temp;
	temp = a;
	a = b;
	b = temp;
}

//模板函数的声明
template <class C>
void myfunc()
{
	cout << "模板函数的调用" << endl;
}
//交换函数测试
void test01()
{
	//调用方法必须制定一个类型
	myfunc<int>();
}

//万能排序模板的设计
//数组输出模板设计
template <class T>
void showArrgy(T arrgy[], int len)
{
	for(int i = 0; i < len; i++)
	{
		cout << arrgy[i] << " " ;
	}
	cout<<endl;
}
//排序主程序
template <class T>
void mySort(T arrgy[] ,int len)
{
	//选择排序的方法实现
	T max;
	for(int i = 0;i < len ;i++)
	{
		max = i;
		for(int j = i + 1; j < len ;j++)
		{
			if(arrgy[j] > arrgy[max])
				max = j;
		}
		if(max != i)
			mySwap(arrgy[i], arrgy[max]);
	}
	showArrgy(arrgy,len);
}

void test02()
{
	int intArr[10] = {4,5,3,2,8,7,9,1};

	char charArr[10] = "ebcadg";

	mySort(charArr,sizeof(charArr)/sizeof(char));
	
	mySort(intArr,sizeof(intArr)/sizeof(int));
}

int main()
{
	int num1,num2;

	num1 = 10;
	num2 = 20;

	cout << "num1 = "<<num1 <<endl;
	cout << "num2 = "<<num2 <<endl<<endl;;

	//调用方法1
	//mySwap(num1,num2);
	//调用方法2
	mySwap<int>(num1,num2);
	cout << "num1 = "<< num1<<endl;
	cout << "num2 = "<< num2<<endl;

	//模板函数的调用
	test01();

	//万能数组排序测试
	test02();

	double num = 'c';

	cout << num <<endl;

	return 0;
}
