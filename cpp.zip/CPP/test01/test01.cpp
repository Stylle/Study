#include <iostream>
#include <string>

using namespace std;

/* *
 *公共继承：父类中的公共权限->子类中的公共权限
			父类中的保护权限->子类中的保护权限
			父类中的私有权限在三种继承方式中都无法访问
 *保护继承：父类中的公共权限->子类中的保护权限
			父类中的保护权限->子类中的保护权限
 *私有继承：父类中的公共权限->子类中的私有权限
			父类中的保护权限->子类中的私有权限
 *在继承中构造函数和析构函数的调用顺序为
			：父类构造-》子类构造-》子类析构-》父类析构
 *多继承方式：（不推荐）定义两个父类  father01  father02
			子类 class son::public father01,public father02
 *菱形继承：基本语法	父类 继承子类01 继承子类02   
			class 菱形结尾继承 ：public 继承子类01 ，public 继承子类02
					父类
				子类01  子类02
				   菱形结尾
 菱形继承造成数据重复 ：子类参用虚继承（虚基类）的方式继承
			基本语法：子类继承中   class 继承子类01 ：virtual public 父类
			第二个子类同上
 * */

//多态与继承的基本用法

class Animal
{
	public:
		int m_A;
		//构造函数
		Animal()
		{
			cout<<"Animal构造函数的调用！"<<endl;
			m_A = 100;
		}
		//虚函数
		void speak()
		{
			cout<<"动物在说话!"<<endl;
		}
	protected:
		//int m_A;
		int m_B;
	private:
		string m_Name;
};

//继承 ： class 子类：权限 父类
class Cat:public Animal
{
public:
	
	int m_A;

	Cat()
	{
		m_A = 200;
	}
	void speak()
	{
		cout<<"m_A = "<<m_A<<endl;

		cout<<"cat speak!"<<endl;
	}
	//父类中的保护成员依旧是保护权限
protected:
	//int m_A;
	//int m_B;
private:
	//不可访问父类中的成员
};

class Dog:public Animal
{
public:
	//函数重写：要求类型相同、函数名相同、形参相同
	void speak()
	{
		cout<<"dog speak!"<<endl;
	}
};

//通过传入的子类调用相应函数
void Animal_Speak(Animal& animal)
{
	animal.speak();
}

class Person 
{
	public:

	protected:

	private:
};

class BedRoom:public Person
{
	
};
void test01()
{
	Cat c1;
	
	Dog d1;

	Animal_Speak(c1);

	Animal_Speak(d1);

	cout<<"Animal->m_A = "<< c1.Animal::m_A<<endl;

	cout<<"Cat->m_A = "<<c1.m_A<<endl;

	cout<<"virator = "<<sizeof(char*)<<endl;

	cout<<"sizeof(int) = "<<sizeof(int)<<endl;

	cout<<"sizeof(string) = "<<sizeof(string)<<endl;

	cout<<"子类大小 = "<<sizeof(c1)<<endl;

	cout<<"父类大小 = "<<sizeof(Animal)<<endl;

	cout<<"空类大小 = "<<sizeof(Person)<<endl;
}

int main()
{
	//继承多态测试
	test01();

	return 0;
}
